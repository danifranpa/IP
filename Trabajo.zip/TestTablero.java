import java.util.Scanner;
public class TestTablero {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.print("\nIntroduce las filas y las columnas del tablero separadas por un espacio: ");
        int f = teclado.nextInt();
        int c = teclado.nextInt();
        System.out.print("Introduce numero de jugadas: ");
        int j = teclado.nextInt();
        Tablero i = new Tablero(2, 2, 1);
        i.ImprimeTablero();
        Tablero t=new Tablero(f, c, j);
        t.ImprimeTablero();
        t.setJugada(j);
        t.juego(teclado);
    }
}
