import javax.swing.JPanel;
import java.util.Scanner;

public class Tablero extends JPanel  {
	//Aquí irían los atributos necesarios
	private int fila, columna, jugada;
	private char[][] tablero;
	//Constructores
	Tablero(int f, int c, int j) {
		setFila(f);
		setColumna(c);
		setJugada(j);
		setTablero(f,c);
		//El constructor debe tener los parámetros oportunos 
		//para inicializar el tablero y el juego
	}

	//Métodos de la clase que implementan el juego: básicamente hacer una
	//jugada, dibujar el estado del tablero y comprobar si la partida se acabó

	// METODOS GET
	/**Metodo getColumna
	 * 
	 * @return columna
	 */
	public int getColumna(){
		return columna;
	}
	/**Metodo getFila
	 * 
	 * @return fila
	 */
	public int getFila(){
		return fila;
	}
	/**Metodo getJugada
	 * 
	 * @return jugada
	 */
	public int getJugada(){
		return jugada;
	}
	/**Metodo getTablero
	 * 
	 * @return tablero
	 */
	public char[][] getTablero(){
		return tablero;
	}

	// METODOS SET
	/**Metodos set del tablero
	 * 
	 * @param numero de columnas
	 */
	public void setColumna(int columna_nuevo){
		if (columna_nuevo > 0 ) columna = columna_nuevo;
	}
	/** @param numero de filas
	*/
	public void setFila(int fila_nuevo){
		if (fila_nuevo > 0) fila = fila_nuevo;
	}
	/** @param numero de jugadas
	*/
	public void setJugada(int jugada_nuevo){
		if (jugada_nuevo > 0) jugada = jugada_nuevo;
	}

	/**Creamos el trablero
	 * @param filas_matriz
	 * @param columnas_matriz
	 */
	public void setTablero(int filas_matriz, int columnas_matriz){
		int i = 0;
		char[][] matriz = new char[filas_matriz][columnas_matriz];
		for(int fila = 0; getFila() < matriz.length; fila++){
			for(int columna = 0; columna < matriz[fila].length; columna++){
				i = (int)(Math.random()*(2-0)+0);
				if (i==0){
					matriz[fila][columna] = 'R';
				} 
				else{
					matriz[fila][columna] = 'B';	
				} 
			}
		}
		tablero = matriz;
	}
	
	/** Metodo ImprimeTablero
	 * 
	 *  @return Imprime el tablero por panatalla
	 */
	public void ImprimeTablero(){
		for(int fila=0;fila<this.getTablero().length;fila++){
			System.out.printf("%d  ",fila+1);
			for(int columna=0;columna<this.getTablero()[1].length;columna++){
				System.out.printf("%s ",this.getTablero()[fila][columna]);
			}
			System.out.println();
		}
		System.out.println();
		System.out.print("   ");
		for(int columna=0;columna<this.getTablero()[1].length;columna++){
			System.out.printf("%d ",columna+1);
		}
	}
	/**Metodo EstadoTablero
	 * Actualiza el estado del tablero segun avance el juego
	 * 
	 * @param filaC1
	 * @param columnaC1
	 * @param filaC2
	 * @param columnaC2
	 * @return Tablero actualizado
	 */
	public void EstadoTablero(int fila1, int columna1, int fila2, int columna2){
		for(int i=fila1-1;i<=fila2-1;i++){
			for(int j=columna1-1;j<=columna2-1;j++){
				this.getTablero()[i][j]='-';
			}
		}
		this.ImprimeTablero();
		System.out.println();
		System.out.println();
		System.out.println();
		for(int i=fila1-1;i<=fila2-1;i++){
			int valor=0;
			for(int j=columna1-1;j<=columna2-1;j++){
				valor=(int)(Math.random()*(2-0)+0);
				if (valor==0){
					this.getTablero()[i][j]='R';
				}
				else{
					this.getTablero()[i][j]='B';
				}
			}
		}
		this.ImprimeTablero();

	}

	/**Metodo RetornaPuntos
	 *Retorna los puntos de cada jugador
	 * 
	 * @param filaC1
	 * @param columnaC1
	 * @param filaC2
	 * @param columnaC2
	 * @return puntos
	 */
	public int puntos(int filaC1, int columnaC1, int filaC2, int columnaC2){
		int puntos=0;
		for(int i=filaC1-1;i<=filaC2-1;i++){
			for(int j=columnaC1-1;j<=columnaC2-1;j++){
				puntos=puntos+10;
			}
		}
		return puntos;
	}
	/**Metodo RetornaPuntos
	 *Verifica si los datos leidos son correctos
	 * 
	 * @param fila1
	 * @param fila2
	 * @param columna1
	 * @param columna2
	 * @param teclado
	 * @return error 
	 */
	public void error(int fila1, int fila2, int columna1, int columna2, Scanner teclado){
		while (fila1 < 1 || fila2 < 1 || columna1 < 1 || columna2 < 1 || 
					!((this.getTablero()[fila1 - 1][columna1 - 1] == this.getTablero()[fila2 - 1][columna2 - 1])
					&& (this.getTablero()[fila1 - 1][columna1 - 1] == this.getTablero()[fila1 - 1][columna2 - 1])
					&& (this.getTablero()[fila1 - 1][columna1 - 1] == this.getTablero()[fila2 - 1][columna1 - 1])
					&& (fila1 != fila2) && (columna1 != columna2))){
				System.out.print("datos erroneos\n");
				System.out.print("Esquina superior izquierda: \n");
				fila1 = teclado.nextInt();
				columna1 = teclado.nextInt();
				System.out.print("Esquina inferior derecha: \n");
				fila2 = teclado.nextInt();
				columna2 = teclado.nextInt();
			}
		
	}

	public void juego (Scanner teclado){
		for (int i = 1; i < this.getJugada(); i++){
			System.out.print("\njugador 1: \n");
			this.ImprimeTablero();
			System.out.print("\n\nEsquina superior izquierda (fila columna): ");
			int fila1 = teclado.nextInt();
			int columna1 = teclado.nextInt();
			System.out.print("\nEsquina inferior derecha (fila columna): ");
			int fila2 = teclado.nextInt();
			int columna2 = teclado.nextInt();
			System.out.println();
			this.error(fila1, fila2, columna1, columna2, teclado);
			this.EstadoTablero(fila1, columna1, fila2, columna2);
			int puntos1 = 0;
			int puntos2 = 0;
			puntos1 = this.puntos(fila1, columna1, fila2, columna2) + puntos1;
			System.out.printf("\n\npuntos del jugador 1: %d\n\n", puntos1);
			System.out.printf("\nPuntos jugador 2: %d\n", puntos2);
			System.out.printf("\nJugadas restantes:%d\n", this.getJugada() - i);
			System.out.print("\nJUGADOR 2\n\n");
			this.ImprimeTablero();
			System.out.print("\n\nEsquina superior izquierda: ");
			fila1 = teclado.nextInt();
			columna1 = teclado.nextInt();
			System.out.print("\nEsquina inferior derecha: ");
			fila2 = teclado.nextInt();
			columna2 = teclado.nextInt();
			this.error(fila1, fila2, columna1, columna2, teclado);
			this.EstadoTablero(fila1, columna1, fila2, columna2);
			puntos2 = this.puntos(fila1, columna1, fila2, columna2) + puntos2;
			System.out.printf("\n\nPuntos jugador 1: %d\n", puntos1);
			System.out.printf("\nPuntos jugador 2: %d\n", puntos2);
			System.out.printf("\nJugadas restantes:%d\n", this.getJugada() - i);
			this.finPartida(i, puntos1, puntos2);
		}	
	}

	/**Metodo FinPartida
	 *  comprobamos si la partida ha terminado
	 * 
	 * @param numero
	 * @param puntos1
	 * @param puntos2
	 * @return Final de la partida
	 */
	public void finPartida(int numero, int puntos1, int puntos2){
		if (numero==this.getJugada()){
			System.out.printf("EL JUEGO HA TERMINADO, puntos del jugador 1:%d\npuntos del jugador 2:%d\n", puntos1,puntos2);
			if (puntos1>puntos2){
				System.out.print("!!EL JUGADOR 1 GANÓ¡¡");
			}
			else if(puntos2>puntos1){
				System.out.print("!!EL JUGADOR 2 GANÓ¡¡");
			}
			else{
				System.out.print("LOS JUGADORES HAN EMPATADO");
			}
		}
	}


	


}













